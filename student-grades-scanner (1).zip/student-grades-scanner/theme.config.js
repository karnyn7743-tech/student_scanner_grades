/** @type {const} */
const themeColors = {
  primary: { light: '#4CAF50', dark: '#4CAF50' },
  background: { light: '#9C27B0', dark: '#6A1B9A' },
  surface: { light: '#f5f5f5', dark: '#1e2022' },
  foreground: { light: '#ffffff', dark: '#ECEDEE' },
  muted: { light: '#687076', dark: '#9BA1A6' },
  border: { light: '#E5E7EB', dark: '#334155' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
  yellow: { light: '#FFEB3B', dark: '#FDD835' },
  pink: { light: '#F8BBD0', dark: '#F06292' },
};

module.exports = { themeColors };
