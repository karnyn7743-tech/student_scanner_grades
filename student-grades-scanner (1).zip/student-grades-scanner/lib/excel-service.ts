import * as FileSystem from "expo-file-system/legacy";
import * as XLSX from "xlsx";

export interface StudentData {
  enrollmentNumber: string;
  name: string;
  class: string;
  secretNumber: string;
  grades: Record<string, number | string>;
}

export interface ExcelData {
  subjects: Array<{ name: string; code: number }>;
  students: StudentData[];
  filePath: string;
}

/**
 * قراءة ملف Excel واستخراج البيانات
 */
export async function readExcelFile(fileUri: string): Promise<ExcelData> {
  try {
    // قراءة الملف كـ base64
    const fileContent = await FileSystem.readAsStringAsync(fileUri, {
      encoding: "base64",
    });

    // تحويل base64 إلى binary
    const binaryString = atob(fileContent);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // قراءة ملف Excel
    const workbook = XLSX.read(bytes, { type: "array" });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];

    // استخراج البيانات
    const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[];

    if (data.length < 2) {
      throw new Error("ملف Excel فارغ أو غير صحيح");
    }

    // استخراج رؤوس الأعمدة (الصف الأول)
    const headers = data[0];

    // استخراج أسماء المواد من الأعمدة E-S (4-18)
    const subjects: Array<{ name: string; code: number }> = [];
    for (let i = 4; i < 19 && i < headers.length; i++) {
      const subjectName = headers[i];
      if (subjectName) {
        subjects.push({
          name: String(subjectName),
          code: i - 3, // الكود يبدأ من 1
        });
      }
    }

    // استخراج بيانات الطلاب (من الصف الثاني فما بعده)
    const students: StudentData[] = [];
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (row.length > 3) {
        const student: StudentData = {
          enrollmentNumber: String(row[0] || ""),
          name: String(row[1] || ""),
          class: String(row[2] || ""),
          secretNumber: String(row[3] || ""),
          grades: {},
        };

        // استخراج الدرجات من الأعمدة E-S
        for (let j = 4; j < 19 && j < row.length; j++) {
          const subjectCode = j - 3;
          student.grades[String(subjectCode)] = row[j] || "";
        }

        students.push(student);
      }
    }

    return {
      subjects,
      students,
      filePath: fileUri,
    };
  } catch (error) {
    throw new Error(`فشل في قراءة ملف Excel: ${error}`);
  }
}

/**
 * البحث عن طالب باستخدام الرقم السري
 */
export function findStudentBySecretNumber(
  students: StudentData[],
  secretNumber: string
): StudentData | null {
  return students.find((student) => student.secretNumber === secretNumber) || null;
}

/**
 * حفظ درجة في ملف Excel
 */
export async function saveGradeToExcel(
  fileUri: string,
  secretNumber: string,
  subjectCode: number,
  grade: number | string,
  students: StudentData[]
): Promise<void> {
  try {
    // قراءة الملف الأصلي
    const fileContent = await FileSystem.readAsStringAsync(fileUri, {
      encoding: "base64",
    });

    const binaryString = atob(fileContent);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // قراءة ملف Excel
    const workbook = XLSX.read(bytes, { type: "array" });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];

    // البحث عن الطالب
    const student = findStudentBySecretNumber(students, secretNumber);
    if (!student) {
      throw new Error("الطالب غير موجود");
    }

    // البحث عن صف الطالب
    const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[];
    let studentRowIndex = -1;
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][3]) === secretNumber) {
        studentRowIndex = i;
        break;
      }
    }

    if (studentRowIndex === -1) {
      throw new Error("لم يتم العثور على صف الطالب");
    }

    // تحديث الدرجة (العمود = 4 + subjectCode - 1)
    const columnIndex = 3 + subjectCode;
    const cellAddress = XLSX.utils.encode_col(columnIndex) + (studentRowIndex + 1);
    worksheet[cellAddress] = { v: grade, t: "n" };

    // حفظ الملف
    const updatedData = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const updatedBase64 = btoa(String.fromCharCode.apply(null, Array.from(updatedData)));

    await FileSystem.writeAsStringAsync(fileUri, updatedBase64, {
      encoding: "base64",
    });
  } catch (error) {
    throw new Error(`فشل في حفظ الدرجة: ${error}`);
  }
}

/**
 * نسخ ملف Excel إلى مجلد درجات الطلاب
 */
export async function copyFileToGradesFolder(
  sourceUri: string,
  fileName: string
): Promise<string> {
  try {
    const docsDir = FileSystem.documentDirectory || "";
    const gradesDir = `${docsDir}Downloads/درجات الطلاب`;

    // التحقق من وجود المجلد وإنشاؤه إذا لم يكن موجوداً
    try {
      const dirInfo = await FileSystem.getInfoAsync(gradesDir);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(gradesDir, { intermediates: true });
      }
    } catch (e) {
      // إذا فشل، حاول إنشاء المجلد مباشرة
      await FileSystem.makeDirectoryAsync(gradesDir, { intermediates: true });
    }

    // نسخ الملف
    const destinationUri = `${gradesDir}/${fileName}`;
    await FileSystem.copyAsync({
      from: sourceUri,
      to: destinationUri,
    });

    return destinationUri;
  } catch (error) {
    throw new Error(`فشل في نسخ الملف: ${error}`);
  }
}
