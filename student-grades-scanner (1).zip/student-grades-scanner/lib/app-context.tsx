import React, { createContext, useContext, useState, ReactNode } from "react";
import { StudentData, ExcelData } from "./excel-service";

interface GradeEntry {
  studentId: string;
  subjectCode: number;
  grade: string;
  timestamp: number;
}

interface AppContextType {
  // بيانات ملف Excel
  excelData: ExcelData | null;
  setExcelData: (data: ExcelData | null) => void;

  // الملف المختار
  selectedFileName: string;
  setSelectedFileName: (name: string) => void;

  // المادة المختارة
  selectedSubjectCode: number | null;
  setSelectedSubjectCode: (code: number | null) => void;

  // بيانات المسح الحالية
  currentSecretNumber: string;
  setCurrentSecretNumber: (number: string) => void;

  currentGrade: string;
  setCurrentGrade: (grade: string) => void;

  // عداد الطلاب المسحوحة
  scannedStudentsCount: number;
  incrementScannedCount: () => void;

  // حالة التحميل
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;

  // سجل الدرجات المدخلة
  gradeHistory: GradeEntry[];
  addGradeToHistory: (entry: GradeEntry) => void;
  undoLastGrade: () => GradeEntry | null;
  clearHistory: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [excelData, setExcelData] = useState<ExcelData | null>(null);
  const [selectedFileName, setSelectedFileName] = useState("");
  const [selectedSubjectCode, setSelectedSubjectCode] = useState<number | null>(null);
  const [currentSecretNumber, setCurrentSecretNumber] = useState("");
  const [currentGrade, setCurrentGrade] = useState("");
  const [scannedStudentsCount, setScannedStudentsCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [gradeHistory, setGradeHistory] = useState<GradeEntry[]>([]);

  const incrementScannedCount = () => {
    setScannedStudentsCount((prev) => prev + 1);
  };

  const addGradeToHistory = (entry: GradeEntry) => {
    setGradeHistory((prev) => [...prev, entry]);
  };

  const undoLastGrade = (): GradeEntry | null => {
    if (gradeHistory.length === 0) return null;
    const lastEntry = gradeHistory[gradeHistory.length - 1];
    setGradeHistory((prev) => prev.slice(0, -1));
    return lastEntry;
  };

  const clearHistory = () => {
    setGradeHistory([]);
  };

  return (
    <AppContext.Provider
      value={{
        excelData,
        setExcelData,
        selectedFileName,
        setSelectedFileName,
        selectedSubjectCode,
        setSelectedSubjectCode,
        currentSecretNumber,
        setCurrentSecretNumber,
        currentGrade,
        setCurrentGrade,
        scannedStudentsCount,
        incrementScannedCount,
        isLoading,
        setIsLoading,
        gradeHistory,
        addGradeToHistory,
        undoLastGrade,
        clearHistory,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useAppContext must be used within AppProvider");
  }
  return context;
}
