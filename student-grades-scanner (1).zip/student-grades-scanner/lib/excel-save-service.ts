import * as FileSystem from "expo-file-system/legacy";
import { ExcelData, StudentData } from "./excel-service";
import * as XLSX from "xlsx";

/**
 * حفظ الدرجة في ملف Excel
 * @param excelData - بيانات Excel المحملة
 * @param filePath - مسار الملف الأصلي
 * @param secretNumber - الرقم السري للطالب
 * @param subjectCode - كود المادة (1-15)
 * @param grade - الدرجة المراد حفظها
 */
export async function saveGradeToExcel(
  excelData: ExcelData,
  filePath: string,
  secretNumber: string,
  subjectCode: number,
  grade: number
): Promise<boolean> {
  try {
    // البحث عن الطالب
    const studentIndex = excelData.students.findIndex(
      (s) => s.secretNumber === secretNumber
    );

    if (studentIndex === -1) {
      throw new Error("الطالب غير موجود");
    }

    // التحقق من كود المادة
    if (subjectCode < 1 || subjectCode > 15) {
      throw new Error("كود المادة غير صحيح");
    }

    // التحقق من الدرجة
    if (grade < 0 || grade > 100) {
      throw new Error("الدرجة يجب أن تكون بين 0 و 100");
    }

    // قراءة الملف الحالي كـ Base64
    const fileContent = await FileSystem.readAsStringAsync(filePath, {
      encoding: FileSystem.EncodingType.Base64,
    });

    // تحويل Base64 إلى Binary
    const binaryString = atob(fileContent);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // قراءة ملف Excel
    const workbook = XLSX.read(bytes, { type: "array" });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];

    // حساب موقع الخلية:
    // الصف = studentIndex + 2 (الصف الأول للعناوين، الثاني للبيانات الأولى)
    // العمود = D + (subjectCode - 1) = E + (subjectCode - 1)
    // لأن D هو الرقم السري، فالمواد تبدأ من E
    const row = studentIndex + 2;
    const columnLetter = String.fromCharCode(69 + subjectCode - 1); // E = 69
    const cellAddress = `${columnLetter}${row}`;

    // كتابة الدرجة في الخلية
    worksheet[cellAddress] = { v: grade, t: "n" };

    // حفظ الملف المحدث
    const updatedWorkbook = XLSX.write(workbook, { type: "array" });
    const updatedBinaryString = String.fromCharCode.apply(
      null,
      Array.from(new Uint8Array(updatedWorkbook))
    );
    const updatedBase64 = btoa(updatedBinaryString);

    // كتابة الملف المحدث
    await FileSystem.writeAsStringAsync(filePath, updatedBase64, {
      encoding: FileSystem.EncodingType.Base64,
    });

    // تحديث البيانات في الذاكرة
    excelData.students[studentIndex].grades[subjectCode - 1] = grade;

    console.log(
      `تم حفظ الدرجة ${grade} للطالب ${secretNumber} في المادة ${subjectCode}`
    );

    return true;
  } catch (error) {
    console.error("خطأ في حفظ الدرجة:", error);
    throw error;
  }
}

/**
 * حفظ عدة درجات دفعة واحدة
 */
export async function saveMultipleGrades(
  excelData: ExcelData,
  filePath: string,
  grades: Array<{
    secretNumber: string;
    subjectCode: number;
    grade: number;
  }>
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  for (const gradeData of grades) {
    try {
      await saveGradeToExcel(
        excelData,
        filePath,
        gradeData.secretNumber,
        gradeData.subjectCode,
        gradeData.grade
      );
      success++;
    } catch (error) {
      console.error(
        `فشل في حفظ درجة الطالب ${gradeData.secretNumber}:`,
        error
      );
      failed++;
    }
  }

  return { success, failed };
}

/**
 * التحقق من وجود درجة محفوظة بالفعل
 */
export function hasGradeSaved(
  excelData: ExcelData,
  secretNumber: string,
  subjectCode: number
): boolean {
  const student = excelData.students.find(
    (s) => s.secretNumber === secretNumber
  );

  if (!student) return false;

  const grade = student.grades[subjectCode - 1];
  return grade !== null && grade !== undefined && grade !== 0;
}

/**
 * الحصول على الدرجة المحفوظة
 */
export function getSavedGrade(
  excelData: ExcelData,
  secretNumber: string,
  subjectCode: number
): number | null {
  const student = excelData.students.find(
    (s) => s.secretNumber === secretNumber
  );

  if (!student) return null;

  const grade = student.grades[subjectCode - 1];

  if (typeof grade === "number") {
    return grade;
  }

  if (typeof grade === "string") {
    const parsed = parseFloat(grade);
    return isNaN(parsed) ? null : parsed;
  }

  return null;
}

/**
 * إحصائيات الحفظ
 */
export interface SaveStatistics {
  totalStudents: number;
  totalSubjects: number;
  savedGrades: number;
  pendingGrades: number;
  completionPercentage: number;
}

/**
 * الحصول على إحصائيات الحفظ
 */
export function getSaveStatistics(
  excelData: ExcelData,
  subjectCode: number
): SaveStatistics {
  const totalStudents = excelData.students.length;
  const totalSubjects = 15;

  let savedGrades = 0;

  for (const student of excelData.students) {
    const grade = student.grades[subjectCode - 1];
    if (grade !== null && grade !== undefined && grade !== 0) {
      savedGrades++;
    }
  }

  const pendingGrades = totalStudents - savedGrades;
  const completionPercentage =
    totalStudents > 0 ? (savedGrades / totalStudents) * 100 : 0;

  return {
    totalStudents,
    totalSubjects,
    savedGrades,
    pendingGrades,
    completionPercentage,
  };
}
