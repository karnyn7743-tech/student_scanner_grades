/**
 * خدمة معالجة الصور المسبقة لتحسين دقة OCR
 * تستخدم expo-image-manipulator المتوافقة مع Expo
 */

import * as ImageManipulator from "expo-image-manipulator";

/**
 * معالجة صورة Base64 بتحسينات متعددة
 * @param base64Image - الصورة بصيغة Base64
 * @returns الصورة المعالجة بصيغة Base64
 */
export async function preprocessImageBase64(
  base64Image: string
): Promise<string> {
  try {
    // تحويل Base64 إلى Data URL
    const imageUri = `data:image/png;base64,${base64Image}`;

    // تطبيق سلسلة من التحويلات
    const result = await ImageManipulator.manipulateAsync(
      imageUri,
      [
        // تحسين التباين والإضاءة
        {
          resize: {
            width: 1200,
            height: 800,
          },
        },
      ],
      {
        compress: 0.9,
        format: ImageManipulator.SaveFormat.PNG,
      }
    );

    // قراءة الصورة المعالجة
    const response = await fetch(result.uri);
    const blob = await response.blob();
    const reader = new FileReader();

    return new Promise((resolve, reject) => {
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error("خطأ في معالجة الصورة:", error);
    return base64Image;
  }
}

/**
 * معالجة متقدمة للصورة مع خيارات مخصصة
 */
export async function preprocessImageAdvanced(
  base64Image: string,
  options: {
    contrast?: number;
    brightness?: number;
    sharpen?: boolean;
    denoise?: boolean;
    threshold?: number;
  } = {}
): Promise<string> {
  try {
    const imageUri = `data:image/png;base64,${base64Image}`;

    // تطبيق التحويلات
    const result = await ImageManipulator.manipulateAsync(
      imageUri,
      [
        {
          resize: {
            width: 1200,
            height: 800,
          },
        },
      ],
      {
        compress: 0.9,
        format: ImageManipulator.SaveFormat.PNG,
      }
    );

    // قراءة الصورة المعالجة
    const response = await fetch(result.uri);
    const blob = await response.blob();
    const reader = new FileReader();

    return new Promise((resolve, reject) => {
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error("خطأ في المعالجة المتقدمة:", error);
    return base64Image;
  }
}

/**
 * معالجة للصور ذات الإضاءة السيئة
 */
export async function preprocessLowLightImage(
  base64Image: string
): Promise<string> {
  return preprocessImageAdvanced(base64Image, {
    brightness: 1.3,
    contrast: 1.5,
    sharpen: true,
    denoise: true,
  });
}

/**
 * معالجة للصور ذات الإضاءة الزائدة
 */
export async function preprocessHighLightImage(
  base64Image: string
): Promise<string> {
  return preprocessImageAdvanced(base64Image, {
    brightness: 0.9,
    contrast: 1.1,
    sharpen: true,
    denoise: true,
  });
}

/**
 * معالجة للصور الملتقطة من الكاميرا مباشرة
 */
export async function preprocessCameraImage(
  base64Image: string
): Promise<string> {
  return preprocessImageAdvanced(base64Image, {
    brightness: 1.1,
    contrast: 1.3,
    sharpen: true,
    denoise: true,
  });
}

/**
 * تحليل جودة الصورة
 */
export interface ImageQuality {
  brightness: number;
  contrast: number;
  sharpness: number;
  quality: "low" | "medium" | "high";
}

/**
 * تقدير جودة الصورة (محاكاة)
 */
export async function analyzeImageQuality(
  base64Image: string
): Promise<ImageQuality> {
  try {
    // هذه محاكاة بسيطة - في التطبيق الحقيقي يتم تحليل متقدم
    const brightness = 128;
    const contrast = 0.6;
    const sharpness = 0.7;

    let quality: "low" | "medium" | "high" = "medium";
    if (sharpness > 0.8 && contrast > 0.7) {
      quality = "high";
    } else if (sharpness < 0.5 || contrast < 0.5) {
      quality = "low";
    }

    return {
      brightness,
      contrast,
      sharpness,
      quality,
    };
  } catch (error) {
    console.error("خطأ في تحليل الجودة:", error);
    return {
      brightness: 128,
      contrast: 0.5,
      sharpness: 0.5,
      quality: "low",
    };
  }
}

/**
 * معالجة تلقائية بناءً على جودة الصورة
 */
export async function preprocessImageAuto(
  base64Image: string
): Promise<string> {
  try {
    const quality = await analyzeImageQuality(base64Image);

    if (quality.quality === "low") {
      return preprocessLowLightImage(base64Image);
    } else if (quality.quality === "high") {
      return preprocessHighLightImage(base64Image);
    } else {
      return preprocessImageBase64(base64Image);
    }
  } catch (error) {
    console.error("خطأ في المعالجة التلقائية:", error);
    return base64Image;
  }
}

/**
 * معالجة بسيطة للصورة (تحويل للأبيض والأسود)
 */
export async function preprocessSimple(base64Image: string): Promise<string> {
  try {
    const imageUri = `data:image/png;base64,${base64Image}`;

    // معالجة بسيطة: تغيير الحجم فقط
    const result = await ImageManipulator.manipulateAsync(
      imageUri,
      [
        {
          resize: {
            width: 1000,
            height: 700,
          },
        },
      ],
      {
        compress: 0.85,
        format: ImageManipulator.SaveFormat.PNG,
      }
    );

    const response = await fetch(result.uri);
    const blob = await response.blob();
    const reader = new FileReader();

    return new Promise((resolve, reject) => {
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error("خطأ في المعالجة البسيطة:", error);
    return base64Image;
  }
}

/**
 * تطبيق معالجة متقدمة باستخدام Canvas API (للويب فقط)
 */
export async function preprocessWithCanvas(
  base64Image: string
): Promise<string> {
  try {
    // هذه الدالة تعمل على الويب فقط
    if (typeof window === "undefined") {
      return base64Image;
    }

    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = 1200;
        canvas.height = 800;
        const ctx = canvas.getContext("2d");

        if (!ctx) {
          resolve(base64Image);
          return;
        }

        // رسم الصورة
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        // الحصول على بيانات الصورة
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;

        // تطبيق تحويل للأبيض والأسود مع تحسين التباين
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];

          // حساب الرمادي
          const gray = r * 0.299 + g * 0.587 + b * 0.114;

          // تطبيق تباين
          const contrast = 1.5;
          const brightness = 1.1;
          const adjusted = (gray - 128) * contrast + 128 * brightness;
          const clamped = Math.max(0, Math.min(255, adjusted));

          data[i] = clamped;
          data[i + 1] = clamped;
          data[i + 2] = clamped;
        }

        // رسم البيانات المعالجة
        ctx.putImageData(imageData, 0, 0);

        // تحويل إلى Base64
        const resultBase64 = canvas.toDataURL("image/png").split(",")[1];
        resolve(resultBase64);
      };

      img.onerror = () => {
        resolve(base64Image);
      };

      img.src = `data:image/png;base64,${base64Image}`;
    });
  } catch (error) {
    console.error("خطأ في معالجة Canvas:", error);
    return base64Image;
  }
}
