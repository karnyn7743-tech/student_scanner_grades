import React, { useState, useRef, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Dimensions,
} from "react-native";
import { BarCodeScanner } from "expo-barcode-scanner";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAppContext } from "@/lib/app-context";
import { findStudentBySecretNumber } from "@/lib/excel-service";

type ScanMode = "subject_code" | "qr_code" | "grade";

export default function CameraScanScreen() {
  const router = useRouter();
  const colors = useColors();
  const appContext = useAppContext();

  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [scanned, setScanned] = useState(false);
  const [scanMode, setScanMode] = useState<ScanMode>("subject_code");
  const [detectedData, setDetectedData] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);

  const scannerRef = useRef<BarCodeScanner>(null);

  // طلب إذن الكاميرا
  useEffect(() => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === "granted");
      if (status !== "granted") {
        Alert.alert("خطأ", "يتطلب التطبيق إذن الوصول للكاميرا");
        router.back();
      }
    })();
  }, []);

  // معالجة نتائج المسح
  const handleBarCodeScanned = async ({ type, data }: any) => {
    if (scanned || isProcessing) return;

    setScanned(true);
    setIsProcessing(true);
    setDetectedData(data);

    try {
      if (scanMode === "subject_code") {
        // مسح كود المادة المطبوع
        await processSubjectCode(data);
      } else if (scanMode === "qr_code") {
        // مسح QR Code (الرقم السري)
        await processQRCode(data);
      }
    } catch (error) {
      Alert.alert("خطأ", `فشل في معالجة البيانات: ${error}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // معالجة كود المادة
  const processSubjectCode = async (code: string) => {
    try {
      // استخراج الأرقام من البيانات
      const extractedCode = code.replace(/\D/g, "");
      const codeNumber = parseInt(extractedCode, 10);

      if (!appContext.selectedSubjectCode) {
        Alert.alert("خطأ", "لم يتم اختيار المادة");
        setScanned(false);
        return;
      }

      // التحقق من توافق كود المادة
      if (codeNumber !== appContext.selectedSubjectCode) {
        Alert.alert(
          "تحذير",
          `المادة التي ستدخل درجاتها ليست التي تم اختيارها.\nالمادة المتوقعة: ${appContext.selectedSubjectCode}\nالمادة المكتشفة: ${codeNumber}`,
          [
            {
              text: "محاولة مرة أخرى",
              onPress: () => setScanned(false),
            },
            {
              text: "متابعة",
              onPress: () => {
                setScanMode("qr_code");
                setScanned(false);
              },
            },
          ]
        );
        return;
      }

      // الانتقال لمسح QR Code
      Alert.alert("نجاح", "تم التحقق من كود المادة بنجاح\nالآن قم بمسح رمز الاستجابة السريعة");
      setScanMode("qr_code");
      setScanned(false);
    } catch (error) {
      Alert.alert("خطأ", `فشل في قراءة كود المادة: ${error}`);
      setScanned(false);
    }
  };

  // معالجة QR Code
  const processQRCode = async (qrData: string) => {
    try {
      if (!appContext.excelData) {
        Alert.alert("خطأ", "لم يتم تحميل ملف Excel");
        setScanned(false);
        return;
      }

      // البحث عن الطالب باستخدام الرقم السري
      const student = findStudentBySecretNumber(appContext.excelData.students, qrData);

      if (!student) {
        Alert.alert(
          "تحذير",
          "طالب غير موجود\nالرقم السري المكتشف: " + qrData,
          [
            {
              text: "محاولة مرة أخرى",
              onPress: () => setScanned(false),
            },
            {
              text: "متابعة بدون تحقق",
              onPress: () => {
                appContext.setCurrentSecretNumber(qrData);
                setScanMode("grade");
                setScanned(false);
              },
            },
          ]
        );
        return;
      }

      // تعيين الرقم السري والعودة للشاشة الرئيسية
      appContext.setCurrentSecretNumber(qrData);
      Alert.alert(
        "نجاح",
        `تم العثور على الطالب: ${student.name}\nالآن يمكنك إدخال الدرجة`
      );

      // العودة للشاشة الرئيسية
      setTimeout(() => {
        router.back();
      }, 1000);
    } catch (error) {
      Alert.alert("خطأ", `فشل في قراءة QR Code: ${error}`);
      setScanned(false);
    }
  };

  // إعادة تشغيل المسح
  const handleRetry = () => {
    setScanned(false);
    setDetectedData("");
  };

  // العودة للشاشة السابقة
  const handleBack = () => {
    setScanMode("subject_code");
    setScanned(false);
    setDetectedData("");
    router.back();
  };

  if (hasPermission === null) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
        <Text className="text-foreground mt-4">جاري طلب إذن الكاميرا...</Text>
      </ScreenContainer>
    );
  }

  if (hasPermission === false) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-error text-center mb-4">لم يتم منح إذن الوصول للكاميرا</Text>
        <TouchableOpacity
          onPress={handleBack}
          className="bg-primary p-4 rounded-lg"
        >
          <Text className="text-foreground font-semibold">العودة</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const scanModeLabel = {
    subject_code: "مسح كود المادة المطبوع",
    qr_code: "مسح رمز الاستجابة السريعة (QR Code)",
    grade: "مسح الدرجة المكتوبة بخط اليد",
  };

  return (
    <ScreenContainer className="p-0" containerClassName="bg-background">
      {/* الرأس */}
      <View className="bg-background px-6 pt-6 pb-4">
        <Text className="text-2xl font-bold text-foreground text-center">
          {scanModeLabel[scanMode]}
        </Text>
      </View>

      {/* منطقة الكاميرا */}
      <View className="flex-1 relative bg-black">
        <BarCodeScanner
          ref={scannerRef}
          onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
          style={{
            flex: 1,
            width: Dimensions.get("window").width,
          }}
        />

        {/* إطار التوجيه */}
        <View className="absolute inset-0 items-center justify-center">
          <View
            className="border-4 border-primary rounded-lg"
            style={{
              width: 250,
              height: 250,
            }}
          />
        </View>

        {/* طبقة شفافة حول الإطار */}
        <View className="absolute inset-0 bg-black bg-opacity-40" pointerEvents="none" />
      </View>

      {/* منطقة المعلومات والأزرار */}
      <View className="bg-background px-6 py-6 gap-4">
        {detectedData && (
          <View className="bg-surface p-4 rounded-lg border border-border">
            <Text className="text-foreground font-semibold mb-2">البيانات المكتشفة:</Text>
            <Text className="text-primary text-lg font-bold">{detectedData}</Text>
          </View>
        )}

        <View className="flex-row gap-3">
          <TouchableOpacity
            onPress={handleRetry}
            disabled={!scanned || isProcessing}
            className="flex-1 bg-primary p-4 rounded-lg active:opacity-80 disabled:opacity-50"
          >
            <Text className="text-foreground font-semibold text-center">
              {isProcessing ? "جاري المعالجة..." : "محاولة مرة أخرى"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleBack}
            disabled={isProcessing}
            className="flex-1 bg-border p-4 rounded-lg active:opacity-80 disabled:opacity-50"
          >
            <Text className="text-foreground font-semibold text-center">العودة</Text>
          </TouchableOpacity>
        </View>

        {/* معلومات إضافية */}
        <View className="bg-surface p-3 rounded-lg border border-border">
          <Text className="text-muted text-sm text-center">
            {scanMode === "subject_code"
              ? "وجه الكاميرا نحو كود المادة المطبوع"
              : "وجه الكاميرا نحو رمز الاستجابة السريعة"}
          </Text>
        </View>
      </View>

      {isProcessing && (
        <View className="absolute inset-0 bg-black bg-opacity-50 items-center justify-center rounded-lg">
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      )}
    </ScreenContainer>
  );
}
