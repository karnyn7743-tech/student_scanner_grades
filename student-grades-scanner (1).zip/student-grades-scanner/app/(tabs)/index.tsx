import React, { useState, useEffect } from "react";
import { useRouter } from "expo-router";
import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import { useAppContext } from "@/lib/app-context";
import { readExcelFile, findStudentBySecretNumber, copyFileToGradesFolder } from "@/lib/excel-service";
import { normalizeNumbers, isValidGrade, parseGrade } from "@/lib/camera-service";
import { saveGradeToExcel } from "@/lib/excel-save-service";

interface Subject {
  name: string;
  code: number;
}

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const appContext = useAppContext();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [showSubjectDropdown, setShowSubjectDropdown] = useState(false);

  // اختيار ملف Excel
  const handleSelectFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ["application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const file = result.assets[0];
        appContext.setSelectedFileName(file.name);
        appContext.setIsLoading(true);

        try {
          // قراءة ملف Excel
          const excelData = await readExcelFile(file.uri);
          appContext.setExcelData(excelData);
          setSubjects(excelData.subjects);

          // نسخ الملف إلى مجلد درجات الطلاب
          const savedPath = await copyFileToGradesFolder(file.uri, file.name);
          console.log("تم حفظ الملف في:", savedPath);

          Alert.alert("نجاح", `تم تحميل الملف بنجاح\nعدد المواد: ${excelData.subjects.length}\nعدد الطلاب: ${excelData.students.length}`);
        } catch (error) {
          Alert.alert("خطأ", `فشل في قراءة الملف: ${error}`);
        } finally {
          appContext.setIsLoading(false);
        }
      }
    } catch (error) {
      Alert.alert("خطأ", "فشل في اختيار الملف");
    }
  };

  // بدء المسح
  const handleStartScan = () => {
    if (!appContext.selectedSubjectCode) {
      Alert.alert("تنبيه", "يرجى اختيار المادة أولاً");
      return;
    }
    // الانتقال إلى شاشة مسح الكاميرا
    router.push("../camera-scan" as any);
  };

  // حفظ الدرجة
  const handleSaveGrade = async () => {
    if (!appContext.currentSecretNumber) {
      Alert.alert("تنبيه", "يرجى مسح رمز الاستجابة السريعة أولاً");
      return;
    }
    if (!appContext.currentGrade) {
      Alert.alert("تنبيه", "يرجى إدخال الدرجة");
      return;
    }

    if (!appContext.excelData || !appContext.selectedSubjectCode) {
      Alert.alert("خطأ", "بيانات غير كاملة");
      return;
    }

    try {
      appContext.setIsLoading(true);

      // البحث عن الطالب
      const student = findStudentBySecretNumber(
        appContext.excelData.students,
        appContext.currentSecretNumber
      );

      if (!student) {
        Alert.alert("خطأ", "الطالب غير موجود");
        return;
      }

      // تطبيع الدرجة (تحويل الأرقام العربية إلى إنجليزية)
      const normalizedGrade = normalizeNumbers(appContext.currentGrade);
      const gradeValue = parseFloat(normalizedGrade);

      if (isNaN(gradeValue)) {
        Alert.alert("خطأ", "الدرجة غير صحيحة");
        return;
      }

      // حفظ الدرجة في ملف Excel
      if (appContext.selectedFileName) {
        const gradesPath = `${FileSystem.documentDirectory}درجات الطلاب/${appContext.selectedFileName}`;
        await saveGradeToExcel(
          appContext.excelData,
          gradesPath,
          appContext.currentSecretNumber,
          appContext.selectedSubjectCode,
          gradeValue
        );
      }

      Alert.alert(
        "نجاح",
        `تم حفظ الدرجة ${gradeValue} للطالب ${student.name}\nالمادة: ${subjects.find(s => s.code === appContext.selectedSubjectCode)?.name}`
      );

      // إعادة تعيين البيانات
      appContext.setCurrentSecretNumber("");
      appContext.setCurrentGrade("");
      appContext.incrementScannedCount();
    } catch (error) {
      Alert.alert("خطأ", `فشل في حفظ الدرجة: ${error}`);
    } finally {
      appContext.setIsLoading(false);
    }
  };

  const selectedSubject = subjects.find(s => s.code === appContext.selectedSubjectCode);

  // دالة التراجع عن آخر إدخال
  const handleUndo = () => {
    if (appContext.gradeHistory.length === 0) {
      Alert.alert("تنبيه", "لا توجد عمليات للتراجع عنها");
      return;
    }

    Alert.alert(
      "تأكيد التراجع",
      "هل تريد حقاً التراجع عن آخر درجة تم إدخالها؟",
      [
        {
          text: "إلغاء",
          onPress: () => {},
          style: "cancel",
        },
        {
          text: "تراجع",
          onPress: () => {
            const lastGrade = appContext.undoLastGrade();
            if (lastGrade) {
              Alert.alert("نجاح", `تم التراجع عن الدرجة ${lastGrade.grade}`);
            }
          },
          style: "destructive",
        },
      ]
    );
  };

  return (
    <ScreenContainer className="p-0" containerClassName="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* الرأس */}
        <View className="bg-background px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground text-center mb-2">
            برنامج إسقاط الدرجات
          </Text>
          <Text className="text-sm text-foreground text-center opacity-80">
            بالأكواد
          </Text>
        </View>

        {/* المحتوى الرئيسي */}
        <View className="flex-1 px-6 pb-6 gap-4">
          {/* قسم اختيار ملف Excel */}
          <View className="gap-2">
            <TouchableOpacity
              onPress={handleSelectFile}
              disabled={appContext.isLoading}
              className="bg-primary p-4 rounded-lg active:opacity-80"
            >
              <Text className="text-foreground font-semibold text-center">
                اختر ملف الأكسيل
              </Text>
            </TouchableOpacity>

            {appContext.selectedFileName ? (
              <View className="bg-surface p-3 rounded-lg border border-border">
                <Text className="text-foreground text-sm" style={{ color: colors.foreground }}>{appContext.selectedFileName}</Text>
              </View>
            ) : (
              <View className="bg-surface p-3 rounded-lg border border-border">
                <Text className="text-foreground text-sm" style={{ color: colors.foreground }}>لم يتم اختيار ملف</Text>
              </View>
            )}
          </View>

          {/* قسم المواد - يظهر دائماً */}
          <View className="gap-2">
            <Text className="text-foreground font-semibold">اختر المادة:</Text>
            {subjects.length > 0 ? (
              <>
                <TouchableOpacity
                  onPress={() => setShowSubjectDropdown(!showSubjectDropdown)}
                  className="bg-yellow p-3 rounded-lg border border-border active:opacity-80"
                >
                  <Text className="text-foreground font-semibold" style={{ color: colors.foreground }}>
                    {selectedSubject ? selectedSubject.name : "اختر المادة"}
                  </Text>
                </TouchableOpacity>

                {showSubjectDropdown && (
                  <View className="bg-surface border border-border rounded-lg overflow-hidden">
                    {subjects.map((subject) => (
                      <TouchableOpacity
                        key={subject.code}
                        onPress={() => {
                          appContext.setSelectedSubjectCode(subject.code);
                          setShowSubjectDropdown(false);
                        }}
                        className="p-3 border-b border-border active:bg-primary active:bg-opacity-20"
                      >
                        <Text className="text-foreground" style={{ color: colors.foreground }}>
                          {subject.name} (كود: {subject.code})
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
              </>
            ) : (
              <View className="bg-surface p-3 rounded-lg border border-border">
                <Text className="text-foreground text-sm" style={{ color: colors.foreground }}>اختر ملف Excel أولاً</Text>
              </View>
            )}
          </View>

          {/* قسم الرقم السري */}
          <View className="gap-2">
            <Text className="text-foreground font-semibold">الرقم السري:</Text>
            <View className="bg-surface p-3 rounded-lg border border-border">
              <Text className="text-foreground" style={{ color: colors.foreground }}>
                {appContext.currentSecretNumber || "سيظهر هنا الرقم السري"}
              </Text>
            </View>
          </View>

          {/* قسم الدرجة */}
          <View className="gap-2">
            <Text className="text-foreground font-semibold">الدرجة:</Text>
            <TextInput
              value={appContext.currentGrade}
              onChangeText={appContext.setCurrentGrade}
              placeholder="ادخل الدرجة"
              placeholderTextColor={colors.muted}
              className="bg-surface p-3 rounded-lg border border-border text-foreground"
              style={{ color: colors.foreground }}
              keyboardType="numeric"
            />
          </View>

          {/* زر ابدأ المسح */}
          <TouchableOpacity
            onPress={handleStartScan}
            disabled={appContext.isLoading || !subjects.length}
            className="bg-primary p-4 rounded-lg active:opacity-80"
          >
            <Text className="text-foreground font-semibold text-center">
              ابدأ المسح
            </Text>
          </TouchableOpacity>

          {/* زر حفظ الدرجة */}
          <TouchableOpacity
            onPress={handleSaveGrade}
            disabled={appContext.isLoading}
            className="bg-primary p-4 rounded-lg active:opacity-80"
          >
            <Text className="text-foreground font-semibold text-center">
              حفظ الدرجة
            </Text>
          </TouchableOpacity>

          {/* زر عرض الإحصائيات */}
          <TouchableOpacity
            onPress={() => router.push("../statistics" as any)}
            className="bg-warning p-4 rounded-lg active:opacity-80"
          >
            <Text className="text-foreground font-semibold text-center">
              عرض الإحصائيات
            </Text>
          </TouchableOpacity>

          {/* زر التراجع */}
          <TouchableOpacity
            onPress={handleUndo}
            disabled={appContext.gradeHistory.length === 0}
            className="bg-error p-4 rounded-lg active:opacity-80"
          >
            <Text className="text-foreground font-semibold text-center">
              تراجع ({appContext.gradeHistory.length})
            </Text>
          </TouchableOpacity>

          {/* منطقة عرض الكاميرا */}
          <View className="bg-surface rounded-lg border-2 border-border p-4 h-64 items-center justify-center">
            <Text className="text-foreground text-center" style={{ color: colors.foreground }}>
              هنا ستظهر شاشة الكاميرا بعد الضغط على زر بدء المسح
            </Text>
          </View>

          {/* عداد الطلاب المسحوحة */}
          <View className="bg-surface p-3 rounded-lg border border-border">
            <Text className="text-foreground text-sm text-center" style={{ color: colors.foreground }}>
              عدد الطلاب المسحوحة: 0
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
