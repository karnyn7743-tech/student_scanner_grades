import { useRouter } from "expo-router";
import { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Dimensions,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAppContext } from "@/lib/app-context";

/**
 * شاشة الإحصائيات
 * تعرض عدد الدرجات المدخلة والمتبقية لكل مادة مع شريط تقدم
 */
export default function StatisticsScreen() {
  const router = useRouter();
  const colors = useColors();
  const appContext = useAppContext();
  const [isLoading, setIsLoading] = useState(false);

  // حساب الإحصائيات
  const calculateStatistics = () => {
    if (!appContext.excelData) {
      return {
        subjects: [],
        totalStudents: 0,
        totalGrades: 0,
        completionPercentage: 0,
      };
    }

    const { subjects, students } = appContext.excelData;
    const totalStudents = students.length;

    // حساب الدرجات المدخلة لكل مادة
    const subjectStats = subjects.map((subject: any, index: number) => {
      const subjectCode = index + 1; // كود المادة (1-15)
      let enteredCount = 0;

      // عد الدرجات المدخلة من بيانات الطلاب
      students.forEach((student: any) => {
        if (student.grades && student.grades[index] !== null && student.grades[index] !== undefined) {
          enteredCount++;
        }
      });

      const completionPercentage =
        totalStudents > 0 ? (enteredCount / totalStudents) * 100 : 0;

      return {
        name: subject,
        code: subjectCode,
        entered: enteredCount,
        remaining: totalStudents - enteredCount,
        total: totalStudents,
        percentage: Math.round(completionPercentage),
      };
    });

    // حساب الإجمالي
    const totalGrades = subjectStats.reduce((sum, s) => sum + s.entered, 0);
    const totalPossible = subjectStats.reduce((sum, s) => sum + s.total, 0);
    const completionPercentage =
      totalPossible > 0 ? (totalGrades / totalPossible) * 100 : 0;

    return {
      subjects: subjectStats,
      totalStudents,
      totalGrades,
      completionPercentage: Math.round(completionPercentage),
    };
  };

  const stats = calculateStatistics();

  // العودة للشاشة الرئيسية
  const goBack = () => {
    router.back();
  };

  // تصدير الإحصائيات
  const exportStatistics = () => {
    Alert.alert(
      "تصدير الإحصائيات",
      `تم إدخال ${stats.totalGrades} درجة من ${stats.totalStudents * stats.subjects.length} درجة إجمالية\nنسبة الإكمال: ${stats.completionPercentage}%`,
      [
        {
          text: "إغلاق",
          onPress: () => {},
        },
        {
          text: "نسخ",
          onPress: () => {
            // يمكن إضافة نسخ للحافظة هنا
            Alert.alert("تم", "تم نسخ الإحصائيات");
          },
        },
      ]
    );
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="gap-4 p-4">
          {/* رأس الشاشة */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">
              إحصائيات الإدخال
            </Text>
            <Text className="text-muted text-sm">
              تتبع تقدم إدخال الدرجات لكل مادة
            </Text>
          </View>

          {/* الإحصائيات الإجمالية */}
          <View className="bg-gradient-to-r from-primary to-primary/80 rounded-lg p-4 gap-3">
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-white/80 text-sm">إجمالي الدرجات المدخلة</Text>
                <Text className="text-3xl font-bold text-white">
                  {stats.totalGrades}
                </Text>
              </View>
              <View className="items-end">
                <Text className="text-white/80 text-sm">من إجمالي</Text>
                <Text className="text-2xl font-bold text-white">
                  {stats.totalStudents * stats.subjects.length}
                </Text>
              </View>
            </View>

            {/* شريط التقدم الإجمالي */}
            <View className="gap-2">
              <View className="flex-row items-center justify-between">
                <Text className="text-white text-sm">نسبة الإكمال</Text>
                <Text className="text-white font-bold">
                  {stats.completionPercentage}%
                </Text>
              </View>
              <View className="h-3 bg-white/30 rounded-full overflow-hidden">
                <View
                  className="h-full bg-white rounded-full"
                  style={{
                    width: `${stats.completionPercentage}%`,
                  }}
                />
              </View>
            </View>
          </View>

          {/* إحصائيات المواد */}
          <View className="gap-2">
            <Text className="text-lg font-bold text-foreground">
              تفاصيل المواد
            </Text>

            {stats.subjects.length === 0 ? (
              <View className="bg-surface rounded-lg p-4 items-center justify-center">
                <Text className="text-muted">لم يتم تحميل ملف Excel</Text>
              </View>
            ) : (
              <View className="gap-2">
                {stats.subjects.map((subject: any) => (
                  <View
                    key={subject.code}
                    className="bg-surface rounded-lg p-4 gap-3"
                  >
                    {/* اسم المادة والكود */}
                    <View className="flex-row items-center justify-between">
                      <View className="flex-1">
                        <Text className="text-foreground font-semibold">
                          {subject.name}
                        </Text>
                        <Text className="text-muted text-xs">
                          كود المادة: {subject.code}
                        </Text>
                      </View>
                      <View className="bg-primary/10 px-3 py-1 rounded-full">
                        <Text className="text-primary font-bold text-sm">
                          {subject.percentage}%
                        </Text>
                      </View>
                    </View>

                    {/* عدد الدرجات */}
                    <View className="flex-row items-center justify-between">
                      <View className="flex-row items-center gap-2">
                        <View className="w-10 h-10 bg-success/20 rounded-lg items-center justify-center">
                          <Text className="text-success font-bold">
                            {subject.entered}
                          </Text>
                        </View>
                        <Text className="text-muted text-sm">مدخلة</Text>
                      </View>

                      <View className="flex-row items-center gap-2">
                        <View className="w-10 h-10 bg-warning/20 rounded-lg items-center justify-center">
                          <Text className="text-warning font-bold">
                            {subject.remaining}
                          </Text>
                        </View>
                        <Text className="text-muted text-sm">متبقية</Text>
                      </View>

                      <View className="flex-row items-center gap-2">
                        <View className="w-10 h-10 bg-border rounded-lg items-center justify-center">
                          <Text className="text-foreground font-bold">
                            {subject.total}
                          </Text>
                        </View>
                        <Text className="text-muted text-sm">إجمالي</Text>
                      </View>
                    </View>

                    {/* شريط التقدم */}
                    <View className="h-2 bg-border rounded-full overflow-hidden">
                      <View
                        className={`h-full rounded-full ${
                          subject.percentage === 100
                            ? "bg-success"
                            : subject.percentage >= 50
                              ? "bg-warning"
                              : "bg-error"
                        }`}
                        style={{
                          width: `${subject.percentage}%`,
                        }}
                      />
                    </View>

                    {/* حالة الإكمال */}
                    <View className="flex-row items-center justify-between pt-2 border-t border-border">
                      <Text className="text-muted text-xs">الحالة:</Text>
                      <Text
                        className={`font-semibold text-xs ${
                          subject.percentage === 100
                            ? "text-success"
                            : subject.percentage >= 50
                              ? "text-warning"
                              : "text-error"
                        }`}
                      >
                        {subject.percentage === 100
                          ? "مكتملة"
                          : subject.percentage >= 50
                            ? "قيد الإنجاز"
                            : "لم تبدأ"}
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            )}
          </View>

          {/* ملخص الإحصائيات */}
          <View className="bg-surface rounded-lg p-4 gap-3">
            <Text className="text-lg font-bold text-foreground">الملخص</Text>

            <View className="flex-row items-center justify-between py-2 border-b border-border">
              <Text className="text-muted">عدد المواد:</Text>
              <Text className="text-foreground font-semibold">
                {stats.subjects.length}
              </Text>
            </View>

            <View className="flex-row items-center justify-between py-2 border-b border-border">
              <Text className="text-muted">عدد الطلاب:</Text>
              <Text className="text-foreground font-semibold">
                {stats.totalStudents}
              </Text>
            </View>

            <View className="flex-row items-center justify-between py-2 border-b border-border">
              <Text className="text-muted">إجمالي الدرجات الممكنة:</Text>
              <Text className="text-foreground font-semibold">
                {stats.totalStudents * stats.subjects.length}
              </Text>
            </View>

            <View className="flex-row items-center justify-between py-2">
              <Text className="text-muted">الدرجات المدخلة:</Text>
              <Text className="text-success font-bold text-lg">
                {stats.totalGrades}
              </Text>
            </View>
          </View>

          {/* الأزرار */}
          <View className="gap-3 pt-4">
            {/* زر التصدير */}
            <TouchableOpacity
              onPress={exportStatistics}
              className="bg-primary rounded-lg p-4 active:opacity-80"
            >
              <Text className="text-center text-white font-bold text-lg">
                عرض الملخص
              </Text>
            </TouchableOpacity>

            {/* زر العودة */}
            <TouchableOpacity
              onPress={goBack}
              className="bg-surface border border-border rounded-lg p-4 active:opacity-80"
            >
              <Text className="text-center text-foreground font-bold text-lg">
                العودة
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
