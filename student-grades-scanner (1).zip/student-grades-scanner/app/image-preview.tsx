import { useLocalSearchParams, useRouter } from "expo-router";
import { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Dimensions,
} from "react-native";
import * as ImageManipulator from "expo-image-manipulator";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import {
  preprocessImageBase64,
  preprocessCameraImage,
  preprocessImageAuto,
  preprocessSimple,
  analyzeImageQuality,
} from "@/lib/image-preprocessing";

/**
 * شاشة معاينة الصورة المعالجة
 * تعرض الصورة الأصلية والمعالجة جنباً إلى جنب
 */
export default function ImagePreviewScreen() {
  const router = useRouter();
  const colors = useColors();
  const params = useLocalSearchParams();

  const [originalImage, setOriginalImage] = useState<string>("");
  const [processedImage, setProcessedImage] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(true);
  const [processingType, setProcessingType] = useState<
    "auto" | "camera" | "simple"
  >("auto");
  const [quality, setQuality] = useState<any>(null);
  const [processingTime, setProcessingTime] = useState(0);
  const [showComparison, setShowComparison] = useState(true);

  // معالجة الصورة عند التحميل
  useEffect(() => {
    processImage();
  }, []);

  // معالجة الصورة
  const processImage = async () => {
    try {
      setIsProcessing(true);
      const imageBase64 = params.imageBase64 as string;

      if (!imageBase64) {
        Alert.alert("خطأ", "لم يتم استقبال الصورة");
        router.back();
        return;
      }

      // حفظ الصورة الأصلية
      setOriginalImage(`data:image/png;base64,${imageBase64}`);

      // تحليل جودة الصورة
      const imageQuality = await analyzeImageQuality(imageBase64);
      setQuality(imageQuality);

      // معالجة الصورة
      const startTime = Date.now();
      let processed: string;

      if (processingType === "camera") {
        processed = await preprocessCameraImage(imageBase64);
      } else if (processingType === "simple") {
        processed = await preprocessSimple(imageBase64);
      } else {
        processed = await preprocessImageAuto(imageBase64);
      }

      const endTime = Date.now();
      setProcessingTime(endTime - startTime);

      setProcessedImage(`data:image/png;base64,${processed}`);
    } catch (error) {
      Alert.alert("خطأ", `فشل في معالجة الصورة: ${error}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // إعادة معالجة الصورة بنوع مختلف
  const reprocessImage = async (type: "auto" | "camera" | "simple") => {
    setProcessingType(type);
    setIsProcessing(true);

    try {
      const imageBase64 = params.imageBase64 as string;
      const startTime = Date.now();
      let processed: string;

      if (type === "camera") {
        processed = await preprocessCameraImage(imageBase64);
      } else if (type === "simple") {
        processed = await preprocessSimple(imageBase64);
      } else {
        processed = await preprocessImageAuto(imageBase64);
      }

      const endTime = Date.now();
      setProcessingTime(endTime - startTime);
      setProcessedImage(`data:image/png;base64,${processed}`);
    } catch (error) {
      Alert.alert("خطأ", `فشل في إعادة معالجة الصورة: ${error}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // التقدم للخطوة التالية (استخراج الدرجة)
  const proceedToOCR = () => {
    router.push({
      pathname: "/grade-review",
      params: {
        imageBase64: params.imageBase64,
        processingType,
      },
    });
  };

  // العودة للكاميرا
  const retakePhoto = () => {
    router.back();
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="gap-4 p-4">
          {/* رأس الشاشة */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">
              معاينة الصورة
            </Text>
            <Text className="text-muted text-sm">
              تحقق من وضوح الأرقام قبل استخراجها
            </Text>
          </View>

          {/* معلومات جودة الصورة */}
          {quality && (
            <View className="bg-surface rounded-lg p-4 gap-2">
              <Text className="font-semibold text-foreground">
                جودة الصورة
              </Text>

              <View className="flex-row items-center justify-between">
                <Text className="text-muted text-sm">الإضاءة:</Text>
                <Text className="text-foreground font-semibold">
                  {quality.brightness}/255
                </Text>
              </View>

              <View className="flex-row items-center justify-between">
                <Text className="text-muted text-sm">التباين:</Text>
                <Text className="text-foreground font-semibold">
                  {(quality.contrast * 100).toFixed(0)}%
                </Text>
              </View>

              <View className="flex-row items-center justify-between">
                <Text className="text-muted text-sm">الحدة:</Text>
                <Text className="text-foreground font-semibold">
                  {(quality.sharpness * 100).toFixed(0)}%
                </Text>
              </View>

              <View className="flex-row items-center justify-between pt-2 border-t border-border">
                <Text className="text-muted text-sm">التقييم:</Text>
                <Text
                  className={`font-bold ${
                    quality.quality === "high"
                      ? "text-success"
                      : quality.quality === "medium"
                        ? "text-warning"
                        : "text-error"
                  }`}
                >
                  {quality.quality === "high"
                    ? "عالية"
                    : quality.quality === "medium"
                      ? "متوسطة"
                      : "منخفضة"}
                </Text>
              </View>
            </View>
          )}

          {/* وقت المعالجة */}
          <View className="bg-surface rounded-lg p-3 flex-row items-center justify-between">
            <Text className="text-muted text-sm">وقت المعالجة:</Text>
            <Text className="text-foreground font-semibold">{processingTime}ms</Text>
          </View>

          {/* عرض الصور */}
          {isProcessing ? (
            <View className="bg-surface rounded-lg p-8 items-center justify-center gap-3">
              <ActivityIndicator size="large" color={colors.primary} />
              <Text className="text-muted">جاري معالجة الصورة...</Text>
            </View>
          ) : showComparison ? (
            <View className="gap-3">
              {/* الصورة الأصلية */}
              <View className="gap-2">
                <Text className="text-sm font-semibold text-foreground">
                  الصورة الأصلية
                </Text>
                {originalImage && (
                  <Image
                    source={{ uri: originalImage }}
                    style={{
                      width: "100%",
                      height: 250,
                      borderRadius: 12,
                      backgroundColor: colors.surface,
                    }}
                    resizeMode="contain"
                  />
                )}
              </View>

              {/* الصورة المعالجة */}
              <View className="gap-2">
                <Text className="text-sm font-semibold text-foreground">
                  الصورة المعالجة ({processingType})
                </Text>
                {processedImage && (
                  <Image
                    source={{ uri: processedImage }}
                    style={{
                      width: "100%",
                      height: 250,
                      borderRadius: 12,
                      backgroundColor: colors.surface,
                    }}
                    resizeMode="contain"
                  />
                )}
              </View>
            </View>
          ) : (
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">
                الصورة المعالجة ({processingType})
              </Text>
              {processedImage && (
                <Image
                  source={{ uri: processedImage }}
                  style={{
                    width: "100%",
                    height: 350,
                    borderRadius: 12,
                    backgroundColor: colors.surface,
                  }}
                  resizeMode="contain"
                />
              )}
            </View>
          )}

          {/* زر تبديل العرض */}
          <TouchableOpacity
            onPress={() => setShowComparison(!showComparison)}
            className="bg-surface rounded-lg p-3 border border-border"
          >
            <Text className="text-center text-foreground font-semibold">
              {showComparison ? "عرض الصورة المعالجة فقط" : "عرض المقارنة"}
            </Text>
          </TouchableOpacity>

          {/* خيارات المعالجة */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">
              نوع المعالجة
            </Text>
            <View className="gap-2">
              <TouchableOpacity
                onPress={() => reprocessImage("auto")}
                className={`p-3 rounded-lg border-2 ${
                  processingType === "auto"
                    ? `border-primary bg-primary bg-opacity-10`
                    : `border-border bg-surface`
                }`}
              >
                <Text
                  className={`text-center font-semibold ${
                    processingType === "auto"
                      ? "text-primary"
                      : "text-foreground"
                  }`}
                >
                  تلقائية (ذكية)
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => reprocessImage("camera")}
                className={`p-3 rounded-lg border-2 ${
                  processingType === "camera"
                    ? `border-primary bg-primary bg-opacity-10`
                    : `border-border bg-surface`
                }`}
              >
                <Text
                  className={`text-center font-semibold ${
                    processingType === "camera"
                      ? "text-primary"
                      : "text-foreground"
                  }`}
                >
                  معالجة الكاميرا
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => reprocessImage("simple")}
                className={`p-3 rounded-lg border-2 ${
                  processingType === "simple"
                    ? `border-primary bg-primary bg-opacity-10`
                    : `border-border bg-surface`
                }`}
              >
                <Text
                  className={`text-center font-semibold ${
                    processingType === "simple"
                      ? "text-primary"
                      : "text-foreground"
                  }`}
                >
                  معالجة بسيطة
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* الأزرار */}
          <View className="gap-3 pt-4">
            {/* زر المتابعة */}
            <TouchableOpacity
              onPress={proceedToOCR}
              className="bg-success rounded-lg p-4 active:opacity-80"
            >
              <Text className="text-center text-white font-bold text-lg">
                متابعة واستخراج الدرجة
              </Text>
            </TouchableOpacity>

            {/* زر إعادة المحاولة */}
            <TouchableOpacity
              onPress={retakePhoto}
              className="bg-warning rounded-lg p-4 active:opacity-80"
            >
              <Text className="text-center text-white font-bold text-lg">
                إعادة التقاط الصورة
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
