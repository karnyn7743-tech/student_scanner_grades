import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Image,
  ScrollView,
} from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAppContext } from "@/lib/app-context";
import {
  recognizeGradeFromBase64,
  formatGrade,
  getConfidenceLevel,
  getConfidenceMessage,
  mockRecognizeGrade,
} from "@/lib/ocr-service";

export default function GradeReviewScreen() {
  const router = useRouter();
  const colors = useColors();
  const appContext = useAppContext();
  const params = useLocalSearchParams();

  const [isProcessing, setIsProcessing] = useState(false);
  const [ocrResult, setOcrResult] = useState<any>(null);
  const [manualGrade, setManualGrade] = useState("");
  const [selectedGrade, setSelectedGrade] = useState<number | null>(null);
  const [confidenceLevel, setConfidenceLevel] = useState<
    "high" | "medium" | "low"
  >("low");
  const [processingTime, setProcessingTime] = useState(0);

  // معالجة الصورة عند التحميل
  useEffect(() => {
    processImage();
  }, []);

  // معالجة الصورة باستخدام OCR
  const processImage = async () => {
    if (!params.imageBase64) {
      Alert.alert("خطأ", "لم يتم توفير صورة للمعالجة");
      router.back();
      return;
    }

    setIsProcessing(true);
    try {
      // استخدام الدالة المحاكاة للاختبار السريع
      // في الإنتاج، استخدم: recognizeGradeFromBase64(params.imageBase64 as string)
      const result = await mockRecognizeGrade(params.imageBase64 as string);

      setOcrResult(result);
      setProcessingTime((result.preprocessingTime || 0) + (result.ocrTime || 0));

      if (result.grade !== null) {
        setSelectedGrade(result.grade);
        setConfidenceLevel(getConfidenceLevel(result.confidence));
      }
    } catch (error) {
      Alert.alert("خطأ", `فشل في معالجة الصورة: ${error}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // قبول الدرجة المستخرجة
  const handleAcceptOCRGrade = () => {
    if (selectedGrade === null) {
      Alert.alert("خطأ", "لم يتم استخراج درجة صحيحة");
      return;
    }

    appContext.setCurrentGrade(selectedGrade.toString());
    Alert.alert("نجاح", `تم قبول الدرجة: ${formatGrade(selectedGrade)}`);
    setTimeout(() => {
      router.back();
    }, 500);
  };

  // تعديل الدرجة يدويًا
  const handleManualGrade = () => {
    if (!manualGrade.trim()) {
      Alert.alert("خطأ", "يرجى إدخال درجة");
      return;
    }

    const grade = parseFloat(manualGrade);
    if (isNaN(grade) || grade < 0 || grade > 100) {
      Alert.alert("خطأ", "الدرجة يجب أن تكون بين 0 و 100");
      return;
    }

    setSelectedGrade(grade);
    appContext.setCurrentGrade(grade.toString());
    Alert.alert("نجاح", `تم تعيين الدرجة: ${formatGrade(grade)}`);
    setTimeout(() => {
      router.back();
    }, 500);
  };

  // إعادة المحاولة
  const handleRetry = () => {
    setOcrResult(null);
    setSelectedGrade(null);
    setManualGrade("");
    processImage();
  };

  return (
    <ScreenContainer className="p-0" containerClassName="bg-background">
      {/* الرأس */}
      <View className="bg-background px-6 pt-6 pb-4">
        <Text className="text-2xl font-bold text-foreground text-center">
          مراجعة الدرجة
        </Text>
      </View>

      {/* المحتوى */}
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        className="px-6 py-4 gap-4"
      >
        {isProcessing ? (
          <View className="flex-1 items-center justify-center gap-4">
            <ActivityIndicator size="large" color={colors.primary} />
            <Text className="text-foreground text-center">
              جاري معالجة الصورة...
            </Text>
          </View>
        ) : ocrResult ? (
          <>
            {/* نتائج OCR */}
            <View className="bg-surface rounded-lg p-4 border border-border gap-3">
              <Text className="text-lg font-bold text-foreground">
                نتائج المسح البصري:
              </Text>

              {/* الدرجة المستخرجة */}
              {ocrResult.grade !== null ? (
                <View className="gap-2">
                  <View className="flex-row items-center justify-between">
                    <Text className="text-foreground">الدرجة المستخرجة:</Text>
                    <Text className="text-2xl font-bold text-primary">
                      {formatGrade(ocrResult.grade)}
                    </Text>
                  </View>

                  {/* النص الخام */}
                  <View className="gap-1">
                    <Text className="text-muted text-sm">النص المكتشف:</Text>
                    <Text className="text-foreground bg-background p-2 rounded text-center">
                      {ocrResult.rawText || "لم يتم العثور على نص"}
                    </Text>
                  </View>

                  {/* مستوى الثقة */}
                  <View className="flex-row items-center justify-between">
                    <Text className="text-muted text-sm">مستوى الثقة:</Text>
                    <Text
                      className={`font-semibold ${
                        confidenceLevel === "high"
                          ? "text-success"
                          : confidenceLevel === "medium"
                            ? "text-warning"
                            : "text-error"
                      }`}
                    >
                      {getConfidenceMessage(confidenceLevel)}
                    </Text>
                  </View>

                  {/* شريط الثقة */}
                  <View className="h-2 bg-border rounded-full overflow-hidden">
                    <View
                      className={`h-full ${
                        confidenceLevel === "high"
                          ? "bg-success"
                          : confidenceLevel === "medium"
                            ? "bg-warning"
                            : "bg-error"
                      }`}
                      style={{
                        width: `${ocrResult.confidence}%`,
                      }}
                    />
                  </View>

                  {/* معلومات المعالجة */}
                  {processingTime > 0 && (
                    <View className="flex-row items-center justify-between pt-2 border-t border-border">
                      <Text className="text-muted text-xs">وقت المعالجة:</Text>
                      <Text className="text-foreground font-semibold text-xs">
                        {processingTime}ms
                      </Text>
                    </View>
                  )}
                </View>
              ) : (
                <View className="gap-2">
                  <Text className="text-error">
                    {ocrResult.error ||
                      "فشل في استخراج الدرجة من الصورة"}
                  </Text>
                  <Text className="text-muted text-sm">
                    يرجى إدخال الدرجة يدويًا أدناه
                  </Text>
                </View>
              )}
            </View>

            {/* إدخال يدوي للدرجة */}
            <View className="bg-surface rounded-lg p-4 border border-border gap-3">
              <Text className="text-lg font-bold text-foreground">
                إدخال يدوي:
              </Text>

              <View className="gap-2">
                <Text className="text-muted text-sm">أدخل الدرجة (0-100):</Text>
                <View className="flex-row gap-2 items-center">
                  <View className="flex-1 border border-border rounded-lg px-3 py-2 bg-background">
                    <Text
                      className="text-foreground text-center text-lg"
                      onPress={() => {
                        // محاكاة حقل إدخال
                      }}
                    >
                      {manualGrade || "أدخل الدرجة"}
                    </Text>
                  </View>
                </View>

                {/* لوحة أرقام سريعة */}
                <View className="gap-2">
                  <Text className="text-muted text-xs">خيارات سريعة:</Text>
                  <View className="flex-row flex-wrap gap-2">
                    {[
                      "85",
                      "90",
                      "95",
                      "100",
                      "75",
                      "80",
                      "70",
                      "60",
                    ].map((grade) => (
                      <TouchableOpacity
                        key={grade}
                        onPress={() => setManualGrade(grade)}
                        className={`flex-1 p-2 rounded-lg border ${
                          manualGrade === grade
                            ? "bg-primary border-primary"
                            : "bg-background border-border"
                        }`}
                      >
                        <Text
                          className={`text-center font-semibold ${
                            manualGrade === grade
                              ? "text-background"
                              : "text-foreground"
                          }`}
                        >
                          {grade}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              </View>
            </View>

            {/* الأزرار */}
            <View className="gap-2">
              {ocrResult.grade !== null && (
                <TouchableOpacity
                  onPress={handleAcceptOCRGrade}
                  className="bg-success p-4 rounded-lg active:opacity-80"
                >
                  <Text className="text-foreground font-semibold text-center">
                    قبول الدرجة المستخرجة ({formatGrade(ocrResult.grade)})
                  </Text>
                </TouchableOpacity>
              )}

              {manualGrade && (
                <TouchableOpacity
                  onPress={handleManualGrade}
                  className="bg-primary p-4 rounded-lg active:opacity-80"
                >
                  <Text className="text-foreground font-semibold text-center">
                    تأكيد الدرجة اليدوية ({manualGrade})
                  </Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity
                onPress={handleRetry}
                className="bg-border p-4 rounded-lg active:opacity-80"
              >
                <Text className="text-foreground font-semibold text-center">
                  إعادة المحاولة
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => router.back()}
                className="bg-error p-4 rounded-lg active:opacity-80"
              >
                <Text className="text-foreground font-semibold text-center">
                  إلغاء
                </Text>
              </TouchableOpacity>
            </View>
          </>
        ) : (
          <View className="flex-1 items-center justify-center gap-4">
            <Text className="text-foreground text-center">
              لم يتم تحميل الصورة
            </Text>
            <TouchableOpacity
              onPress={handleRetry}
              className="bg-primary p-4 rounded-lg active:opacity-80"
            >
              <Text className="text-foreground font-semibold">إعادة المحاولة</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
