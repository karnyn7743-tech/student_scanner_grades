# 📱 تعليمات بناء تطبيق إسقاط الدرجات على جهازك

## المتطلبات الأساسية

قبل البدء، تأكد من تثبيت:

### 1. Node.js و npm
- **تحميل**: https://nodejs.org/ (اختر LTS)
- **التحقق**:
```bash
node --version
npm --version
```

### 2. Java Development Kit (JDK)
- **تحميل**: https://www.oracle.com/java/technologies/downloads/
- **الإصدار المطلوب**: Java 11 أو أحدث
- **التحقق**:
```bash
java -version
```

### 3. Android SDK
- **الخيار الأول**: تحميل Android Studio من https://developer.android.com/studio
- **الخيار الثاني**: تحميل Command Line Tools فقط

### 4. متغيرات البيئة (Environment Variables)
بعد تثبيت Android SDK، أضف المسارات التالية:

#### على Windows:
```
ANDROID_HOME = C:\Users\YourUsername\AppData\Local\Android\Sdk
PATH += %ANDROID_HOME%\platform-tools
PATH += %ANDROID_HOME%\tools
```

#### على macOS/Linux:
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/platform-tools
export PATH=$PATH:$ANDROID_HOME/tools
```

---

## الخطوة 1: تحضير المشروع

### 1.1 تحميل المشروع
```bash
# انسخ مجلد المشروع إلى جهازك
cd /path/to/student-grades-scanner
```

### 1.2 تثبيت المكتبات
```bash
# تثبيت pnpm (مدير الحزم)
npm install -g pnpm

# تثبيت المكتبات
pnpm install
```

### 1.3 التحقق من الإعدادات
```bash
# التحقق من عدم وجود أخطاء TypeScript
pnpm check
```

---

## الخطوة 2: الاختبار السريع (اختياري)

قبل البناء، يمكنك اختبار التطبيق في Expo Go:

```bash
# بدء خادم التطوير
pnpm dev

# أو مباشرة للـ Android
pnpm android
```

ثم امسح رمز QR بتطبيق Expo Go على هاتفك.

---

## الخطوة 3: بناء APK

### الطريقة الأولى: البناء المحلي (الأسرع)

```bash
# تثبيت Expo CLI
npm install -g expo-cli

# بناء APK محلياً
eas build --local --platform android
```

**المميزات:**
- ✅ سريع (10-15 دقيقة)
- ✅ بدون حساب Expo
- ✅ يعمل بدون إنترنت مستقر

**المتطلبات:**
- Java JDK مثبت
- Android SDK مثبت

---

### الطريقة الثانية: البناء السحابي (موصى به)

```bash
# 1. إنشء حساب Expo (مجاني)
# اذهب إلى https://expo.dev وأنشئ حساب

# 2. تسجيل الدخول
eas login

# 3. إعداد المشروع
eas build:configure

# 4. بناء APK
eas build --platform android --release
```

**المميزات:**
- ✅ موثوق جداً
- ✅ يعمل على أي جهاز
- ✅ أداة رسمية من Expo

**المتطلبات:**
- حساب Expo (مجاني)
- إنترنت مستقر

---

## الخطوة 4: تثبيت APK على الهاتف

### الطريقة الأولى: عبر USB

```bash
# 1. وصل الهاتف بـ USB
# 2. فعّل وضع المطور والتصحيح عبر USB

# 3. ثبّت APK
adb install path/to/app.apk
```

### الطريقة الثانية: تحميل مباشر

1. انسخ ملف APK إلى هاتفك
2. افتح مدير الملفات
3. اضغط على ملف APK
4. اتبع التعليمات

### الطريقة الثالثة: رابط التحميل

بعد البناء السحابي، ستحصل على رابط تحميل مباشر.

---

## استكشاف الأخطاء

### المشكلة: "Android SDK not found"
**الحل:**
```bash
# تحقق من متغيرات البيئة
echo $ANDROID_HOME

# أو ثبّت SDK مباشرة
sdkmanager "platforms;android-34"
```

### المشكلة: "Java not found"
**الحل:**
```bash
# تحقق من Java
java -version

# إذا لم يكن مثبتاً، ثبّت JDK من https://www.oracle.com/java/
```

### المشكلة: "Build failed"
**الحل:**
```bash
# امسح الملفات المؤقتة
pnpm install --force
rm -rf node_modules/.cache
rm -rf .expo

# حاول البناء مرة أخرى
eas build --local --platform android
```

---

## معلومات البناء

| المعلومة | القيمة |
|---------|--------|
| **اسم التطبيق** | إسقاط الدرجات |
| **الإصدار** | 1.0.0 |
| **الحد الأدنى لـ Android** | 8 (API 24) |
| **الحد الأقصى لـ Android** | 14+ (API 34+) |
| **البنى المدعومة** | armeabi-v7a, arm64-v8a |

---

## بعد التثبيت

### الأذونات المطلوبة
عند فتح التطبيق أول مرة، سيطلب:
- ✅ إذن الكاميرا
- ✅ إذن الوصول للملفات
- ✅ إذن الكتابة على التخزين

### الملفات المحفوظة
الدرجات تُحفظ في:
```
/sdcard/Downloads/درجات الطلاب/
```

---

## نصائح مهمة

1. **استخدم هاتفاً بـ Android 8+** للتوافقية الكاملة
2. **تأكد من توفر مساحة** على الهاتف (500 MB على الأقل)
3. **استخدم ملف Excel صحيح** بالصيغة المطلوبة
4. **اختبر الكاميرا** قبل الاستخدام الفعلي

---

## الدعم والمساعدة

إذا واجهت مشاكل:
1. تحقق من الأخطاء أعلاه
2. اقرأ السجلات بعناية
3. تأكد من تثبيت جميع المتطلبات
4. حاول البناء مرة أخرى

---

**تم إنشاء هذه التعليمات بتاريخ:** 2026-06-24
**إصدار التطبيق:** 1.0.0
